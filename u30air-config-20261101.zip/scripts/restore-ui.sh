#!/bin/sh
# Restore only the reviewed UI files on an existing compatible OpenWrt system.
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root on the U30 Air.' >&2; exit 1; }
base=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
src="$base/templates/rootfs"
[ -f /etc/openwrt_release ] && [ -d "$src/usr" ] && [ -d "$src/www" ] || exit 1
backup="/root/u30air-ui-before-restore-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup"
for prefix in usr www; do
    (cd "$src" && find "$prefix" -type f) | while IFS= read -r path; do
        case "$path" in *..*|/*) echo 'Unsafe path' >&2; exit 1;; esac
        target="/$path"
        if [ -f "$target" ]; then
            mkdir -p "$backup/$(dirname "$path")"
            cp -p "$target" "$backup/$path"
        fi
        mkdir -p "$(dirname "$target")"
        cp "$src/$path" "$target"
    done
done
echo "UI files restored; previous files: $backup"
echo 'Refresh the browser. Network, passwords and proxy subscriptions were not changed.'
