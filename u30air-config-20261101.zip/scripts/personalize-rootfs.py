"""Personalize this trusted rootfs archive offline; never flash or upload secrets."""
import argparse
import getpass
import io
import re
import secrets
import shutil
import subprocess
import tarfile
from pathlib import Path


def replacement(key, wifi):
    if key == 'CHANGE_ME_KEY':
        return wifi
    if key == 'CHANGE_ME_CONTROLLER_SECRET':
        return secrets.token_urlsafe(32)
    if key == 'CHANGE_ME_ICCID':
        return ''
    if key in ('CHANGE_ME_OIX_PASSWD', 'CHANGE_ME_DASHBOARD_PASSWORD'):
        return secrets.token_urlsafe(32)
    raise ValueError('Unknown placeholder; inspect template first: ' + key)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.output.exists() or args.source.resolve() == args.output.resolve():
        raise SystemExit('Choose a new output filename, e.g. private-personalized-rootfs.tar.gz')
    openssl = shutil.which('openssl')
    if not openssl:
        raise SystemExit('OpenSSL is required. Run on Linux/WSL with openssl installed.')
    password = getpass.getpass('New root password (12+ characters): ')
    if len(password) < 12 or password != getpass.getpass('Repeat root password: '):
        raise SystemExit('Passwords must match and contain at least 12 characters.')
    wifi = getpass.getpass('New Wi-Fi password (12-63 ASCII characters): ')
    if not 12 <= len(wifi) <= 63 or any(not 32 <= ord(c) < 127 or c in "'\\" for c in wifi):
        raise SystemExit('Use 12-63 ASCII characters without apostrophes or backslashes.')
    root_hash = subprocess.run([openssl, 'passwd', '-6', '-stdin'], input=password + '\n',
                               text=True, capture_output=True, check=True).stdout.strip()
    if not root_hash.startswith('$6$'):
        raise SystemExit('Unexpected password hash format.')
    temporary = args.output.with_name(args.output.name + '.partial')
    try:
        with tarfile.open(args.source, 'r:gz') as source, tarfile.open(temporary, 'w:gz') as dest:
            for member in source:
                if not member.isfile():
                    dest.addfile(member)
                    continue
                data = source.extractfile(member).read()
                name = member.name.removeprefix('./')
                if name == 'etc/shadow':
                    data = ('root:' + root_hash + ':0:0:99999:7:::\n').encode()
                elif name.startswith(('etc/config/', 'etc/openclash/config/')):
                    text = data.decode('utf-8')
                    text = re.sub(r'CHANGE_ME_[A-Z_0-9]+', lambda m: replacement(m[0], wifi), text)
                    data = text.encode('utf-8')
                member.size = len(data)
                dest.addfile(member, io.BytesIO(data))
        temporary.replace(args.output)
    finally:
        temporary.unlink(missing_ok=True)
    print('Created local personalized archive. Do not upload it: it contains credentials.')


if __name__ == '__main__':
    main()
