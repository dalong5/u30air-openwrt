'use strict';
'require view';
return view.extend({
  render: function() {
    var address = 'http://' + window.location.hostname + ':8088/';
    return E('div', {}, [
      E('div', {style:'display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px'}, [
        E('h2', {style:'margin:0'}, '文件存储'),
        E('div', {}, [
          E('a', {href:address,target:'_blank',rel:'noopener',class:'btn cbi-button-positive'}, '新窗口打开')
        ])
      ]),
      E('p', {style:'color:#778578;font-size:12px'}, '文件保存在 /mnt/storage 独立分区。HTTP 仅供可信局域网使用；请使用文件管理账户登录。'),
      E('iframe', {src:address,title:'文件存储可视化管理',style:'width:100%;height:calc(100vh - 220px);min-height:580px;border:1px solid #dce3db;border-radius:12px;background:#f6f8f5',loading:'eager'})
    ]);
  },
  handleSaveApply: null,
  handleSave: null,
  handleReset: null
});
